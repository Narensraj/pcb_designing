Readme.txt file for the Manufacturing directory.

Student Names: Naren Subburaj
Student Numbers: 8772452
Phone Contact Information: 5483332113
Board Size:6x4 inch

https://can01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.freedfm.com%2Ffreedfm%2F0034948605831105%2Fresults%2Fsummary2.htm&amp;data=04%7C01%7Cnsubburaj2452%40conestogac.on.ca%7C375f54cce5cf41b9669e08da02cb5f23%7C4ddd393ae98a4404841fc4becdd925a5%7C0%7C0%7C637825370025025836%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C2000&amp;sdata=0qpRV4lVNL7YxfB7HaJAFMOHryQ5fBwLwiXZsuDyv9M%3D&amp;reserved=0
